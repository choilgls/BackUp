﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Sockets;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using static Sample1.Common.Mediator;
using static Sample1.Common.Client_Info;
using System.Windows.Markup;
using Sample1.View;
using System.Windows.Threading;
using System.Diagnostics;
using Sample1.ViewModel;
using System.IO;
using System.Windows.Documents;

namespace Sample1.Common
{
    public class MultiSocketServer
    {

        private TcpListener listener;
        private const int BUFFER_SIZE = 1024;
        //private readonly List<TcpClient> clients = new List<TcpClient>();

        IPAddress ipAddress = IPAddress.Parse("192.168.0.148");
        int port = 12345;
        public void Start()
        {

            Register("SEND", SendMessage);
            Register("SENDTO", SendMessageTo);
            // Create a TCPListener on the local IP address and port 1234
            listener = new TcpListener(ipAddress, port);

            // Start listening for incoming client connections
            listener.Start();

            //Console.WriteLine("Waiting for a connection...");
            NotifyColleagues("ADDLOG", "Waiting for a connection...");

            // Start a Task to handle incoming client connections
            Task.Run(() => HandleIncomingConnections());

        }

        private async Task HandleIncomingConnections()
        {

            while (true)
            {

                // Accept a client connection asynchronously
                TcpClient client = await listener.AcceptTcpClientAsync();

                //Console.WriteLine("Client connected: {0}", client.Client.RemoteEndPoint);
                NotifyColleagues("ADDLOG", client.Client.RemoteEndPoint.ToString().Split(':')[0] + " - Client connected");

                // Add the client to the list
                lock (client_Infos)
                {
                    Client_Info info = new Client_Info(client);
                    client_Infos.Add(info);
                    Task.Run(() => HandleClientConnection(info));

                }

                /*RoomView window = new RoomView(client);
                window.Show();*/
                // Start a Task to handle the client connection

            }
        }

        /*private async Task HandleClientConnection(TcpClient client)
        {
            try
            {
                // Receive data from the client
                byte[] buffer = new byte[BUFFER_SIZE];
                int bytesRead = 0;

                NetworkStream stream = client.GetStream();
                while ((bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length)) > 0)
                {
                    string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);
                    //Console.WriteLine("{0} Received data: {1}", client.Client.RemoteEndPoint, data);
                    //Console.WriteLine("Client connected: {0}", client.Client.RemoteEndPoint);
                    //NotifyColleagues("ADDLOG", client.Client.RemoteEndPoint + " >> " + data);
                    NotifyColleagues("ADDLOG", client.Client.RemoteEndPoint.ToString().Split(':')[0] + " : " + data);
                    
                    foreach(Client_Info info in client_Infos)
                    {
                        if (info.Name == client.Client.RemoteEndPoint.ToString().Split(':')[1])
                        {
                            DispatcherService.Invoke((System.Action)(() =>
                            {
                                
                                //info._ChattList.Add(new TextData() {  Position="Left", Background="white", Text = data, TextPosition="Left", Time = DateTime.Now.ToString("t"),TimePosition="Right",Condition=true });
                            }));
                        }

                            
                    }
                    // Broadcast the received data to all connected clients
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
            }
            finally
            {
                // Remove the client from the list when the connection is closed

                //NotifyColleagues("ADDLOG", "Client disconnected: "+ client.Client.RemoteEndPoint);

                //Console.WriteLine("Client disconnected: {0}", client.Client.RemoteEndPoint);
                lock (client_Infos)
                {
                    foreach(Client_Info info in client_Infos)
                    {
                        if(info.Client == client)
                        {
                            NotifyColleagues("ADDLOG", client.Client.RemoteEndPoint.ToString().Split(':')[0] + " - Client disconnected");
                            client.Close();
                            client_Infos.Remove(info);
                        }
                    }

                    
                }
            }
        }*/
        private async Task HandleClientConnection(Client_Info info)
        {
            string ip = info.Client.Client.RemoteEndPoint.ToString().Split(':')[0];
            try
            {
                // Receive data from the client
                byte[] buffer = new byte[BUFFER_SIZE];
                string previousData = null;
                int bytesRead = 0;

                NetworkStream stream = info.Client.GetStream();
                stream.ReadTimeout = 2500;
                while (true)
                {
                    if (info.Client.Client.Poll(0, SelectMode.SelectRead) && info.Client.Client.Receive(new byte[1], SocketFlags.Peek) == 0)
                        break;

                    bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                    if (bytesRead <= 0) 
                        break;

                    string data = Encoding.ASCII.GetString(buffer, 0, bytesRead);

                    if (data != previousData)
                    {
                        // 새로운 데이터를 처리
                        info.Message = data;
                        previousData = data;
                    }

                }

            }
            catch (IOException ex)
            {
                // Handle IOException that occurs when the client disconnects abruptly
                NotifyColleagues("ADDLOG", "Client disconnected abruptly: " + ip);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error: {0}", ex.Message);
            }
            finally
            {
                NotifyColleagues("ADDLOG", ip + " - Client disconnected");
                info.Client.Close();
                client_Infos.Remove(info);
            }
        }



        public void SendMessage(object obj)
        {
            string message = obj.ToString();
            foreach (var info in client_Infos)
            {

                NotifyColleagues("ADDLOG", info.Client.Client.RemoteEndPoint.ToString().Split(':')[0] + " - Send Your Info");
                byte[] dataBytes = Encoding.ASCII.GetBytes(message);
                info.Client.GetStream().WriteAsync(dataBytes, 0, dataBytes.Length);
            };
        }
        public void SendMessageTo(object obj)
        {
            string str = obj.ToString();
            string name = str.Split("!@#$%")[0];
            string message = str.Split("!@#$%")[1];

            foreach (var info in client_Infos)
            {
                if (info.Client.Client.RemoteEndPoint.ToString().Split(':')[0] == name)
                {

                    NotifyColleagues("ADDSetLog", info.Client.Client.RemoteEndPoint.ToString().Split(':')[0] + " " + message + " Send");
                    byte[] dataBytes = Encoding.ASCII.GetBytes(message);
                    info.Client.GetStream().WriteAsync(dataBytes, 0, dataBytes.Length);
                    return;
                }

            };
            NotifyColleagues("ADDSetLog", name + "Not Exit");
        }


        public void Stop()
        {
            // Stop listening for incoming client connections
            listener.Stop();

            // Close all connected clients
            lock (client_Infos)
            {
                foreach (var info in client_Infos)
                {
                    //NotifyColleagues("ADDLOG", "Client disconnected: " + client.Client.RemoteEndPoint);
                    NotifyColleagues("ADDLOG", info.Client.Client.RemoteEndPoint.ToString().Split(':')[0] + " - Client disconnected");
                    info.Client.Close();
                }
            }
            client_Infos.Clear();
        }

        private async Task CheckClientsStatus()
        {
            while (true)
            {
                await Task.Delay(5000); // wait 5 seconds
                NotifyColleagues("ADDLOG", "client check");
                lock (client_Infos)
                {
                    // check all clients
                    foreach (var info in Client_Info.client_Infos)
                    {
                        

                        if (info.Client.Client.Poll(0, SelectMode.SelectRead) && info.Client.Client.Available == 0)
                            //if (info.Client.Client.Poll(0, SelectMode.SelectRead) && info.Client.Client.Receive(new byte[1], SocketFlags.Peek) == 0)
                        {
                            //NotifyColleagues("ADDLOG", "Client disconnected : " + client.Client.RemoteEndPoint);
                            NotifyColleagues("ADDLOG", info.Client.Client.RemoteEndPoint.ToString().Split(':')[0] + " - Client disconnected");
                            //Console.WriteLine("Client disconnected: {0}", client.Client.RemoteEndPoint);
                            info.Client.Close();
                            client_Infos.Remove(info);
                        }
                        else
                        {
                            NotifyColleagues("ADDLOG", info.Client.Client.RemoteEndPoint.ToString().Split(':')[0] + " - Client Alive");
                        }
                    }
                }
            }
        }

        public void StartCheckingClientsStatus()
        {
            Task.Run(() => CheckClientsStatus());
        }
    }
}
