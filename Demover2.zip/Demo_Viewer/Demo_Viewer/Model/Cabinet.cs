﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;

namespace Demo_Viewer.Model
{
    public class Cabinet : INotifyPropertyChanged
    {
        public Cabinet()
        {
            Name = "";
            ID = "";
            state = false;
            Racks = new ObservableCollection<Rack>();
            CPMIP_List = new ObservableCollection<string> { "" };

            Num = 1;
        }
        public Cabinet(string name, string iD)
        {
            Name = name;
            ID = iD;
            state = false;
            Racks = new ObservableCollection<Rack> ();
            CPMIP_List = new ObservableCollection<string>{""};
            
            Num = 1;
        }
        public void AddRack(string name,string id)
        {
            Racks.Add(new Rack(name, id));
            Num++;
        }

        public ObservableCollection<Rack> Racks
        {
            get { return racks; }
            set
            {
                if (racks != value)
                {
                    racks = value;
                    OnPropertyChanged(nameof(Racks));
                }
            }
        }
        public ObservableCollection<string> CPMIP_List
        {
            get { return cPMIP_List; }
            set
            {
                if (cPMIP_List != value)
                {
                    cPMIP_List = value;
                    OnPropertyChanged(nameof(CPMIP_List));
                }
            }
        }
        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        } 
        public string ID
        {
            get { return iD; }
            set
            {
                if (iD != value)
                {
                    iD = value;
                    OnPropertyChanged(nameof(ID));
                }
            }
        }

        public int Num { get; set; }
        private string name { get; set; }
        private string iD { get; set; }
        private bool state { get; set; }
        private ObservableCollection<string> cPMIP_List { get; set; }
        private ObservableCollection<Rack> racks { get; set; }

        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
