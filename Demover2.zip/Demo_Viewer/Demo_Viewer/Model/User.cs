﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Viewer.Model
{
    public class User
    {
        static public User user;
        public User(string name, string rank, string iD, string pW, bool saveChecked, string authority)
        {
            Name = name;
            Rank = rank;
            ID = iD;
            PW = pW;
            SaveChecked = saveChecked;
            Authority = authority;
        }

        public string Name { get; set; }
        public string Rank { get; set; }
        public string ID { get; set; }
        public string PW { get; set; }
        public bool SaveChecked { get; set; }
        public string Authority { get; set; }
       
    }
}
