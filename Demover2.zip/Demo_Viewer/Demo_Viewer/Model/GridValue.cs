﻿using Demo_Viewer.Common;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Viewer.Model
{
    public class GridValue : ViewModelBase
    {
        private string g_MenuValue;
        public string G_MenuValue { get { return g_MenuValue; } set { g_MenuValue = value; OnPropertyChanged("G_MenuValue"); } }

        private string g_MainValue;
        public string G_MainValue { get { return g_MainValue; } set { g_MainValue = value; OnPropertyChanged("G_MainValue"); } }

        private string g_TreeValue;
        public string G_TreeValue { get { return g_TreeValue; } set { g_TreeValue = value; OnPropertyChanged("G_TreeValue"); } }

        public GridValue(string g_MenuValue, string g_MainValue, string g_TreeValue)
        {
            this.G_MenuValue = g_MenuValue;
            this.G_MainValue = g_MainValue;
            this.G_TreeValue = g_TreeValue;
        }

        public void SetValue(string g_MenuValue, string g_MainValue, string g_TreeValue)
        {
            this.G_MenuValue = g_MenuValue;
            this.G_MainValue = g_MainValue;
            this.G_TreeValue = g_TreeValue;
        }

    }
}
