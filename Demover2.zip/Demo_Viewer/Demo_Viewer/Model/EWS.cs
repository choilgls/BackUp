﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Viewer.Model
{
    public  class EWS
    {
        public EWS(string name, string id,string ip)
        {
            Name = name;
            ID = id;
            IP = ip;
            State = false;
        }

        public string Name { get; set; }
        public string ID { get; set; }
        public string IP { get; set; }
        public bool State { get; set; }
    }
}
