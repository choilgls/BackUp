﻿using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using static Demo_Viewer.ViewModel.Main_ViewModel;

namespace Demo_Viewer.Common
{
    public class XmlHelper
    {
        public XmlHelper()
        {



        }
        public void XmlRead(string str)
        {
            string filePath = str;

            ObservableCollection<Cabinet> cabinets = new ObservableCollection<Cabinet>();

            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.Load(filePath);

            XmlNode root = xmlDoc.SelectSingleNode("root");
            if (root != null)
            {
                XmlNodeList cabinetNodes = root.SelectNodes("Cabinet");
                if (cabinetNodes != null)
                {
                    System.Console.WriteLine(cabinetNodes.Count.ToString());
                    foreach (XmlNode cabinetNode in cabinetNodes)
                    {
                        Cabinet cabinet = ReadCabinet(cabinetNode);
                        cabinets.Add(cabinet);
                        S_Top.Num++;
                        foreach(Rack rack in cabinet.Racks)
                        {
                            foreach(CPM cpm in rack.CPMs)
                            {
                                cabinet.CPMIP_List.Add(cpm.IP);
                            }
                        }
                        
                    }
                }
            }
            S_Top.Cabinets = cabinets;
        }

        public  Cabinet ReadCabinet(XmlNode cabinetNode)
        {
            Cabinet cabinet = new Cabinet();
            if (cabinetNode.Attributes != null)
            {
                XmlAttribute nameAttribute = cabinetNode.Attributes["name"];
                XmlAttribute idAttribute = cabinetNode.Attributes["id"];

                if (nameAttribute != null)
                    cabinet.Name = nameAttribute.Value;
                if (idAttribute != null)
                    cabinet.ID = idAttribute.Value;
            }

            XmlNodeList rackNodes = cabinetNode.SelectNodes("Rack");
            if (rackNodes != null)
            {
                foreach (XmlNode rackNode in rackNodes)
                {
                    Rack rack = ReadRack(rackNode);
                    cabinet.Racks.Add(rack);
                    cabinet.Num++;
                }
            }

            return cabinet;
        }

        public  Rack ReadRack(XmlNode rackNode)
        {
            Rack rack = new Rack();
            if (rackNode.Attributes != null)
            {
                XmlAttribute nameAttribute = rackNode.Attributes["name"];
                XmlAttribute idAttribute = rackNode.Attributes["id"];

                if (nameAttribute != null)
                    rack.Name = nameAttribute.Value;
                if (idAttribute != null)
                    rack.ID = idAttribute.Value;
            }

            XmlNodeList cpmNodes = rackNode.SelectNodes("CPM");
            if (cpmNodes != null)
            {
                foreach (XmlNode cpmNode in cpmNodes)
                {
                    CPM cpm = ReadCpm(cpmNode);
                    rack.CPMs.Add(cpm);
                    rack.C_Num++;
                }
            }

            XmlNodeList iomNodes = rackNode.SelectNodes("IOM");
            if (iomNodes != null)
            {
                foreach (XmlNode iomNode in iomNodes)
                {
                    IOM iom = ReadIom(iomNode);
                    rack.IOMs.Add(iom);
                    rack.I_Num++;
                }
            }

            return rack;
        }

        public  CPM ReadCpm(XmlNode cpmNode)
        {
            CPM cpm = new CPM();
            if (cpmNode.Attributes != null)
            {
                XmlAttribute nameAttribute = cpmNode.Attributes["name"];
                XmlAttribute idAttribute = cpmNode.Attributes["id"];
                XmlAttribute ipAttribute = cpmNode.Attributes["ip"];
                

                if (nameAttribute != null)
                    cpm.Name = nameAttribute.Value;
                if (idAttribute != null)
                    cpm.ID = idAttribute.Value;
                if (ipAttribute != null)
                    cpm.IP = ipAttribute.Value;

            }

            return cpm;
        }

        public  IOM ReadIom(XmlNode iomNode)
        {
            IOM iom = new IOM();
            if (iomNode.Attributes != null)
            {
                XmlAttribute nameAttribute = iomNode.Attributes["name"];
                XmlAttribute idAttribute = iomNode.Attributes["id"];
                XmlAttribute ipAttribute = iomNode.Attributes["ip"];
                XmlAttribute cpm_01_ip_Attribute = iomNode.Attributes["cpm_01_ip"];
                XmlAttribute cpm_02_ip_Attribute = iomNode.Attributes["cpm_02_ip"];

                if (nameAttribute != null)
                    iom.Name = nameAttribute.Value;
                if (idAttribute != null)
                    iom.ID = idAttribute.Value;
                if (ipAttribute != null)
                    iom.IP = ipAttribute.Value;
                if (cpm_01_ip_Attribute != null)
                    iom.Cpm1_Ip = cpm_01_ip_Attribute.Value;
                if (cpm_02_ip_Attribute != null)
                    iom.Cpm2_Ip = cpm_02_ip_Attribute.Value;
            }

            return iom;
        }


        public void XmlWrite(string str)
        {
            string filePath = str;


            XmlWriterSettings settings = new XmlWriterSettings();
            settings.Indent = true;  // 들여쓰기 설정

            using (XmlWriter writer = XmlWriter.Create(filePath, settings))
            {
                writer.WriteStartDocument();  // XML 문서 시작

                writer.WriteStartElement("root");  // 최상위 요소 시작

                foreach (Cabinet ca in S_Top.Cabinets)
                {
                    WriteCabinet(writer, ca);
                }
                /*WriteLevel1(writer, "Node A", "Node B");
                WriteLevel1(writer, "Node C", "Node D");
                WriteLevel1(writer, "Node E", "Node F");*/

                writer.WriteEndElement();  // 최상위 요소 종료

                writer.WriteEndDocument();  // XML 문서 종료
            }

            Console.WriteLine("XML 파일이 생성되었습니다.");
        }
        public void WriteCabinet(XmlWriter writer, Cabinet cabinet)
        {
            writer.WriteStartElement("Cabinet");
            writer.WriteAttributeString("name", cabinet.Name);
            writer.WriteAttributeString("id", cabinet.ID);
            foreach (Rack rack in cabinet.Racks)
            {
                WriteRack(writer, rack);
            }
            writer.WriteEndElement();
        }
        public void WriteRack(XmlWriter writer, Rack rack)
        {
            writer.WriteStartElement("Rack");
            writer.WriteAttributeString("name", rack.Name);
            writer.WriteAttributeString("id", rack.ID);
            foreach (CPM cpm in rack.CPMs)
            {
                WriteCpm(writer, cpm);
            }
            foreach (IOM iom in rack.IOMs)
            {
                WriteIom(writer, iom);
            }
            writer.WriteEndElement();
        }
        public void WriteCpm(XmlWriter writer, CPM cpm)
        {
            writer.WriteStartElement("CPM");
            writer.WriteAttributeString("name", cpm.Name);
            writer.WriteAttributeString("id", cpm.ID);
            writer.WriteAttributeString("ip", cpm.IP);
            writer.WriteEndElement();
        }
        public void WriteIom(XmlWriter writer, IOM iom)
        {
            writer.WriteStartElement("IOM");
            writer.WriteAttributeString("name", iom.Name);
            writer.WriteAttributeString("id", iom.ID);
            writer.WriteAttributeString("ip", iom.IP);
            writer.WriteAttributeString("cpm_01_ip", iom.Cpm1_Ip);
            writer.WriteAttributeString("cpm_02_ip", iom.Cpm2_Ip);
            writer.WriteEndElement();
        }
    }
}
