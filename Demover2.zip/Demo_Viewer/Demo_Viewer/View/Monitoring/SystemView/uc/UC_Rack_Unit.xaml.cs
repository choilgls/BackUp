﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Demo_Viewer.Common.Mediator;

namespace Demo_Viewer.View.Monitoring.SystemView.uc
{
    /// <summary>
    /// UC_Rack_Unit.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_Rack_Unit : UserControl
    {
        public ICommand ItemClickCommand { get; private set; }
        public UC_Rack_Unit()
        {
            InitializeComponent();
            ItemClickCommand = new RelayCommad<Object>(ItemClickCommandMethod);
        }
        private void ItemClickCommandMethod(object parameter)
        {
            NotifyColleagues("Set_Pick_Rack", _Rack);
            NotifyColleagues("Config", _Rack);
        }
        public static readonly DependencyProperty _RackProperty = DependencyProperty.Register(
         "_Rack", typeof(Rack), typeof(UC_Rack_Unit), new PropertyMetadata(null));
        public Rack _Rack
        {
            get { return (Rack)GetValue(_RackProperty); }
            set { SetValue(_RackProperty, value); }
        }


        public static readonly DependencyProperty CpmWidthProperty = DependencyProperty.Register(
         "CpmWidth", typeof(string), typeof(UC_Rack_Unit), new PropertyMetadata(null));
        public string CpmWidth
        {
            get { return (string)GetValue(CpmWidthProperty); }
            set { SetValue(CpmWidthProperty, value); }
        }


        public static readonly DependencyProperty IomWidthProperty = DependencyProperty.Register(
         "IomWidth", typeof(string), typeof(UC_Rack_Unit), new PropertyMetadata(null));
        public string IomWidth
        {
            get { return (string)GetValue(IomWidthProperty); }
            set { SetValue(IomWidthProperty, value); }
        }

    }
}
