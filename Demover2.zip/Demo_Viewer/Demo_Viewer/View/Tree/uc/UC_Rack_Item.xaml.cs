﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;
using static Demo_Viewer.Common.Mediator;
using static Demo_Viewer.ViewModel.Main_ViewModel;
namespace Demo_Viewer.View.Tree.uc
{
    /// <summary>
    /// UC_Rack_Item.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_Rack_Item : UserControl
    {
        public ICommand ItemClickCommand { get; private set; }
        public ICommand IconCommand { get; private set; }
        protected bool _visible { get; set; }
        public UC_Rack_Item()
        {
            ItemClickCommand = new RelayCommad<Object>(ItemClickCommandMethod);
            IconCommand = new RelayCommad<Object>(IconCommandMethod);
            InitializeComponent();
            Icon2 = "▼";
            _visible = true;
            Height_CPM = "auto";
            Height_IOM = "auto";
        }

        private void ItemClickCommandMethod(object parameter)
        {
            NotifyColleagues("Config", parameter);
            foreach(Cabinet ca in S_Top.Cabinets)
            {
                foreach(Rack rack in ca.Racks)
                {
                    if(rack == _Rack)
                    {
                        NotifyColleagues("Set_Pick_Cabinet", ca);
                        return;
                    }
                }
            }
            
        }
        private void IconCommandMethod(object parameter)
        {
            if (!_visible)
            {
                _visible = true;
                Icon2 = "▼";
                Height_CPM = "auto";
                Height_IOM = "auto";
            }
            else
            {
                _visible = false;
                Icon2 = "▶";
                Height_CPM = "0";
                Height_IOM = "0";
            }
        }
        public static readonly DependencyProperty _RackProperty = DependencyProperty.Register(
        "_Rack", typeof(Rack), typeof(UC_Rack_Item), new PropertyMetadata(null));
        public Rack _Rack
        {
            get { return (Rack)GetValue(_RackProperty); }
            set { SetValue(_RackProperty, value); }
        }

        public static readonly DependencyProperty Height_CPM_Property = DependencyProperty.Register(
        "Height_CPM", typeof(string), typeof(UC_Rack_Item), new PropertyMetadata(string.Empty));
        public string Height_CPM
        {
            get { return (string)GetValue(Height_CPM_Property); }
            set { SetValue(Height_CPM_Property, value); }
        }

        public static readonly DependencyProperty Height_IOM_Property = DependencyProperty.Register(
       "Height_IOM", typeof(string), typeof(UC_Rack_Item), new PropertyMetadata(string.Empty));
        public string Height_IOM
        {
            get { return (string)GetValue(Height_IOM_Property); }
            set { SetValue(Height_IOM_Property, value); }
        }

        public static readonly DependencyProperty Icon2Property = DependencyProperty.Register(
        "Icon2", typeof(string), typeof(UC_Rack_Item), new PropertyMetadata(string.Empty));
        public string Icon2
        {
            get { return (string)GetValue(Icon2Property); }
            set { SetValue(Icon2Property, value); }
        }
    }
}
