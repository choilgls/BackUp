﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Demo_Viewer.Common.Mediator;
using static Demo_Viewer.ViewModel.Main_ViewModel;
namespace Demo_Viewer.View.Tree.uc
{
    /// <summary>
    /// UC_IOM_Item.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_IOM_Item : UserControl
    {
        public ICommand ItemClickCommand { get; private set; }
        public UC_IOM_Item()
        {
            InitializeComponent();
            ItemClickCommand = new RelayCommad<Object>(ItemClickCommandMethod);
        }

        private void ItemClickCommandMethod(object parameter)
        {
            NotifyColleagues("Config", parameter);
            foreach (Cabinet ca in S_Top.Cabinets)
            {
                foreach (Rack rack in ca.Racks)
                {
                    foreach (IOM iom in rack.IOMs)
                        if (iom == _IOM)
                    {
                        NotifyColleagues("Set_Pick_Cabinet", ca);
                        return;
                    }
                }
            }
        }

        public static readonly DependencyProperty _IOMProperty = DependencyProperty.Register(
        "_IOM", typeof(IOM), typeof(UC_IOM_Item), new PropertyMetadata(null));
        public IOM _IOM
        {
            get { return (IOM)GetValue(_IOMProperty); }
            set { SetValue(_IOMProperty, value); }
        }
        
    }
}
