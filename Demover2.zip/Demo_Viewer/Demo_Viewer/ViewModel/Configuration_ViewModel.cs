﻿using System.Text.RegularExpressions;
using Demo_Viewer.Common;
using Demo_Viewer.Model;
using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls.Primitives;
using System.Windows.Input;
using static Demo_Viewer.Common.Mediator;
using static Demo_Viewer.ViewModel.Main_ViewModel;

namespace Demo_Viewer.ViewModel
{
    public class Configuration_ViewModel : ViewModelBase
    {
        public static object s_object =new object();
        private Item _selected_Item = new Item();
        public Item Selected_Item { get { return _selected_Item; } set { _selected_Item = value; OnPropertyChanged("Selected_Item"); } }
        private Item add_Item = new Item();
        public Item Add_Item { get { return add_Item; } set { add_Item = value; OnPropertyChanged("Add_Item"); } }
        private string pick_Type { get; set; }
        public string Pick_Type { get { return pick_Type; } set { pick_Type = value; OnPropertyChanged("Pick_Type"); Set_AddItem(); } }

        private ObservableCollection<string> cPMIP_List = new ObservableCollection<string>();
        public ObservableCollection<string> CPMIP_List { get { return cPMIP_List; } set { cPMIP_List = value; OnPropertyChanged("CPMIP_List"); } }
        public string Pick_Cpm1_IP { get { return Add_Item.Cpm1_Ip; } set { Add_Item.Cpm1_Ip = value; OnPropertyChanged("Pick_Cpm1_IP"); } }
        public string Pick_Cpm2_IP { get { return Add_Item.Cpm2_Ip; } set { Add_Item.Cpm2_Ip = value; OnPropertyChanged("Pick_Cpm2_IP"); } }

        private ObservableCollection<string> TopList = new ObservableCollection<string>() { "Cabinet" };
        private ObservableCollection<string> CabinetList = new ObservableCollection<string>() { "Rack" };
        private ObservableCollection<string> RackList = new ObservableCollection<string>() { "CPM","IOM" };
        private ObservableCollection<string> EmptyList = new ObservableCollection<string>();        
        private ObservableCollection<string> string_list=new ObservableCollection<string>();
        public ObservableCollection<string> String_List { get { return string_list; } set { string_list = value; OnPropertyChanged("String_List"); } }
        private string iom_Add_Item_Visibility { get; set; }
        public string Iom_Add_Item_Visibility { get { return iom_Add_Item_Visibility; } set { iom_Add_Item_Visibility = value; OnPropertyChanged("Iom_Add_Item_Visibility"); } }
        private string iom_Select_Item_Visibility { get; set; }
        public string Iom_Select_Item_Visibility { get { return iom_Select_Item_Visibility; } set { iom_Select_Item_Visibility = value; OnPropertyChanged("Iom_Select_Item_Visibility"); } }
        public ICommand ItemClickCommand { get; private set; }
        public ICommand AddCommand { get; private set; }
        public ICommand DeleteCommand { get; private set; }
        public ICommand SaveCommand { get; private set; }


        public Configuration_ViewModel()
        {
            Register("Config", PickData);
            ItemClickCommand = new RelayCommad<Object>(ItemClickCommandMethod);
            AddCommand = new RelayCommad<Object>(AddCommandMethod);
            DeleteCommand = new RelayCommad<Object>(DeleteCommandMethod);
            SaveCommand = new RelayCommad<Object>(SaveCommandMethod);
            Iom_Add_Item_Visibility = "Hidden";
            Iom_Select_Item_Visibility = "Hidden";
        }

        private void SaveCommandMethod(object parameter)
        {
            MessageBox.Show("수정 기능 추가 예정");
        }
        private void AddCommandMethod(object parameter)
        {
            
            if (Add_Item.Name == "" || Add_Item.ID == "")
            {
                MessageBox.Show("정보 입력 필수.");
                return;
            }
            object obj = s_object;
            if (obj is string)
            {
                if (S_Top.Cabinets.Count() >= 5)
                {
                    MessageBox.Show("Cabinet 최대 개수 5EA 초과.");
                    Add_Item.Set_Property("NOP", "NOP", "NOP", "NOP");
                    return;
                }
                S_Top.AddCabinet(Add_Item.Name,Add_Item.ID);
                //S_Top.Cabinets.Add(new Cabinet(Add_Item.Name, Add_Item.ID));
                Add_Item.Set_Property("CA" + S_Top.Num, S_Top.Num.ToString(),"Cabinet","-");
            }
            else if (obj is Cabinet)
            {
                Cabinet cabinet = (Cabinet)obj;
                foreach (Cabinet ca in S_Top.Cabinets)
                {
                    
                    if (ca.ID == cabinet.ID)
                    {
                        if (ca.Racks.Count >= 4)
                        {
                            MessageBox.Show("Rack 최대 개수 4EA 초과.");
                            Add_Item.Set_Property("NOP", "NOP", "NOP", "NOP");
                            return;
                        }
                        ca.AddRack(Add_Item.Name,Add_Item.ID);
                        //ca.Racks.Add(new Rack(Add_Item.Name, Add_Item.ID));
                        Add_Item.Set_Property("Rack" + ca.Num, ca.ID + "_R" + ca.Num, "Rack", "-");
                        break;
                    }
                }

            }
            else if (obj is Rack)
            {
                if( Add_Item.IP == "")
                {
                    MessageBox.Show("정보 입력 필수.");
                    return;
                }
                Rack rack = (Rack)obj;
                foreach (Cabinet ca in S_Top.Cabinets)
                {
                    foreach (Rack ra in ca.Racks)
                    {
                        if(ra.ID == rack.ID)
                        {
                            if (add_Item.Type == "CPM" && Add_Item.ID != "NOP")
                            {
                                if (rack.CPMs.Count() >= 2)
                                {
                                    MessageBox.Show("Rack 내부 CPM 최대 개수 2EA 초과.");
                                    Add_Item.Set_Property("NOP", "NOP", "NOP", "NOP");
                                    return;
                                }
                                ra.AddCPM(Add_Item.Name, Add_Item.ID, Add_Item.IP);
                                ca.CPMIP_List.Add(Add_Item.IP);
                                Add_Item.Set_Property("CPM" + rack.CPMs.Count(), rack.ID + "_C" + rack.CPMs.Count(),"CPM", "192.168.1." + Regex.Replace(rack.ID, @"\D", "") + rack.CPMs.Count());
                                
                            }                                
                            else if (add_Item.Type == "IOM")
                            {
                                if (ra.IOMs.Count >= 5)
                                {
                                    MessageBox.Show("Rack 내부 IOM 최대 개수 5EA 초과.");
                                    Add_Item.Set_Property("NOP", "NOP", "NOP", "NOP","","");
                                    return;
                                }
                                //MessageBox.Show(Add_Item.Cpm1_Ip + "," + Add_Item.Cpm2_Ip);
                                if (Add_Item.Cpm1_Ip == "" && Add_Item.Cpm2_Ip == "")
                                {
                                    MessageBox.Show("최소 한개의 CPM IP 선택 필수");
                                }
                                else 
                                {
                                    if (Add_Item.Cpm1_Ip == Add_Item.Cpm2_Ip)
                                    {
                                        MessageBox.Show("Check CPM IP");
                                        return;
                                    }
                                    ra.AddIOM(Add_Item.Name, Add_Item.ID, Add_Item.IP, Add_Item.Cpm1_Ip, Add_Item.Cpm2_Ip);
                                    Add_Item.Set_Property("IOM" + rack.I_Num, rack.ID + "_I" + rack.I_Num, "IOM", "192.168.0." + Regex.Replace(rack.ID, @"\D", "") + rack.I_Num);
                                    return;
                                }

                                
                            }
                        }
                    }
                }
            }
        }
        private void DeleteCommandMethod(object parameter)
        {
            object obj = s_object;
            if (Selected_Item.Name == "" || Selected_Item.ID == "")
            {
                MessageBox.Show("정보 입력 필수.");
                return;
            }
            if (obj is string)
            {
                if (MessageBox.Show("TOP 하위 모든 정보를 삭제 하시겠습니까?", "타이틀", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    S_Top.Cabinets.Clear();
                    //Selected_Item.Set_Property("", "", "","");
                    Selected_Item.Set_Property("");
                    NotifyColleagues("ReSet_Pick_Cabinet", "");
                }
            }
            else if (obj is Cabinet)
            {
                Cabinet cabinet = (Cabinet)obj;
                foreach (Cabinet ca in S_Top.Cabinets)
                {
                    if(ca.ID == cabinet.ID)
                    {
                        if (ca.Racks.Count() > 0)
                        {
                            if (MessageBox.Show("하위 Rack이 존재 합니다.\n해당 기기를 삭제 하시겠습니까?", "타이틀", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                            {
                                S_Top.Cabinets.Remove(ca);
                                Selected_Item.Set_Property("", "", "", "", "", "");
                                NotifyColleagues("ReSet_Pick_Cabinet", "");
                                return;
                            }
                        }
                        else
                        {
                            S_Top.Cabinets.Remove((Cabinet)ca);
                            Selected_Item.Set_Property("", "", "", "", "", "");
                            return;
                        }
                    }
                }

            }
            else if (obj is Rack)
            {
                Rack rack = (Rack)obj;
                foreach (Cabinet ca in S_Top.Cabinets)
                {
                    foreach (Rack ra in ca.Racks)
                    {
                        if(ra.ID == rack.ID)
                        {
                            if (ra.CPMs.Count() > 0 || ra.IOMs.Count() > 0)
                            {
                                if(MessageBox.Show("하위 보드가 존재 합니다.\n해당 기기를 삭제 하시겠습니까?", "타이틀", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                                {
                                    ra.CPMs.Clear();
                                    ra.IOMs.Clear();
                                    ca.Racks.Remove(ra);
                                    Selected_Item.Set_Property("", "", "", "", "", "");
                                    return;
                                }
                                else
                                {
                                    return;
                                }
                                
                            }
                            else
                            {
                                ca.Racks.Remove(ra);
                                Selected_Item.Set_Property("", "", "", "", "", "");
                                return;
                            }
                        }    

                    }
                }
            }
            else if (obj is CPM)
            {
                CPM cpm = (CPM)obj;
                foreach (Cabinet ca in S_Top.Cabinets)
                {
                    foreach (Rack ra in ca.Racks)
                    {
                        foreach (CPM c in ra.CPMs)
                        {
                            if (cpm.ID == c.ID)
                            {
                                bool flag = false;
                                foreach (Cabinet ca2 in S_Top.Cabinets)
                                {
                                    foreach (Rack ra2 in ca.Racks)
                                    {
                                        foreach (IOM i2 in ra.IOMs)
                                        {
                                            if (i2.Cpm1_Ip == c.IP || i2.Cpm2_Ip == c.IP)
                                            {
                                                MessageBox.Show(i2.IP + ": Check IOM's CPM IP");
                                                flag = true;
                                                break;
                                            }
                                         }
                                        if (flag)
                                            break;
                                    }
                                    if (flag)
                                        break;
                                }
                                if (flag)
                                {
                                    return;
                                }
                                ca.CPMIP_List.Remove(c.IP);
                                ra.CPMs.Remove(c);
                                Selected_Item.Set_Property("", "", "", "", "", "");
                                return;
                            }
                        }

                    }
                }
            }
            else if (obj is IOM)
            {
                IOM iom = (IOM)obj;

                foreach (Cabinet ca in S_Top.Cabinets)
                {
                    foreach (Rack ra in ca.Racks)
                    {
                        foreach (IOM i in ra.IOMs)
                        {
                            if (iom.ID == i.ID)
                            {
                                ra.IOMs.Remove(i);
                                Selected_Item.Set_Property("", "", "", "", "", "");
                                return;
                            }
                        }

                    }
                }
            }
        }
        private void ItemClickCommandMethod(object parameter)
        {
            MessageBox.Show("asd");
        }
        
        public void Set_AddItem()
        {
            object obj = s_object;
            Iom_Add_Item_Visibility = "Hidden";
            if (obj is string && Pick_Type=="Cabinet")
            {
                Add_Item.Name = "CA" + S_Top.Num;
                Add_Item.ID= S_Top.Num.ToString();
                //Add_Item.Set_Property("CA" + S_Top.Num, S_Top.Num.ToString(), "Cabinet", "-");
            }
            else if (obj is Cabinet && Pick_Type=="Rack")
            {
                Cabinet cabinet = (Cabinet)obj;
                //CPMIP_List = cabinet.CPMIP_List;
                Add_Item.Set_Property("Rack" + cabinet.Num, cabinet.ID + "_R" + cabinet.Num, "Rack", "-");
            }
            else if (obj is Rack)
            {
                Rack rack = (Rack)obj;
                bool flag = false;
                foreach (Cabinet ca in S_Top.Cabinets)
                {
                    foreach(Rack ra in ca.Racks)
                    {
                        if (ra == rack)
                        {
                            CPMIP_List = ca.CPMIP_List;
                            flag= true;
                            break;
                        }
                    }
                    if (flag)
                        break;
                }

                if (Pick_Type == "CPM")
                {
                    if (rack.CPMs.Count() >= 2)
                    {
                        Add_Item.Set_Property("NOP", "NOP", "NOP", "NOP");
                        return;
                    }
                    Add_Item.Set_Property("CPM" + rack.CPMs.Count(), rack.ID + "_C" + rack.CPMs.Count(), "CPM", "192.168.1." + Regex.Replace(rack.ID, @"\D", "")+ rack.CPMs.Count());
                }
                else if (Pick_Type=="IOM")
                {
                    Iom_Add_Item_Visibility = "Visible";
                    Add_Item.Set_Property("IOM" + rack.I_Num, rack.ID + "_I" + rack.I_Num, "IOM", "192.168.0." + Regex.Replace(rack.ID, @"\D", "")+rack.I_Num);      //Regex.Replace(strText, @"\D", "");
                }
                
            }            
        }
        public void PickData(object obj)
        {
            s_object=obj;
            Iom_Add_Item_Visibility = "Hidden";
            Iom_Select_Item_Visibility = "Hidden";
            Selected_Item.Set_Property("-");
            Add_Item.Set_Property("");
            if (obj == null)
            {
                MessageBox.Show("NULL");
                return;
            }
            if (obj is string)
            {
                string str = (string)obj;
                String_List=TopList;
                Selected_Item.Set_Property("TOP", "N/A", "N/A","-");
                
            }
            else if (obj is EWS)
            {
                EWS EWS_ = (EWS)obj;
                String_List = EmptyList;
                Selected_Item.Set_Property(EWS_.Name, EWS_.ID, "EWS",EWS_.IP);

            }
            else if(obj is Cabinet)
            {
                Cabinet cabinet = (Cabinet)obj;                
                String_List = CabinetList;
                Selected_Item.Set_Property(cabinet.Name, cabinet.ID, "Cabinet", "-");
            }
            else if (obj is Rack)
            {
                Rack rack = (Rack)obj;
                String_List = RackList;
                Selected_Item.Set_Property(rack.Name, rack.ID, "Rack", "-");
            }
            else if (obj is CPM)
            {
                CPM cpm = (CPM)obj;
                String_List = EmptyList;
                Selected_Item.Set_Property(cpm.Name, cpm.ID, "CPM",cpm.IP);
            }
            else if (obj is IOM)
            {
                IOM iom = (IOM)obj;
                String_List = EmptyList;
                Selected_Item.Set_Property(iom.Name, iom.ID, "IOM",iom.IP,iom.Cpm1_Ip,iom.Cpm2_Ip);
                Iom_Select_Item_Visibility = "Visible";
            }
            

        }
        public void Set_AddItem(string name, string id, string type)
        {
            Add_Item.Name = name;
            Add_Item.ID = id;
            Add_Item.Type = type;
        }

        public class Item:INotifyPropertyChanged
        {
            private string name { get; set; }
            private string type { get; set; }
            private string id { get; set; }
            private string ip { get; set; }
            private string cpm1_Ip { get; set; }
            private string cpm2_Ip { get; set; }

            public string Name
            {
                get { return name; }
                set
                {
                    if (name != value)
                    {
                        name = value;
                        OnPropertyChanged(nameof(Name));
                    }
                }
            }
            public string Type
            {
                get { return type; }
                set
                {
                    if (type != value)
                    {
                        type = value;
                        OnPropertyChanged(nameof(Type));
                    }
                }
            }
            public string ID
            {
                get { return id; }
                set
                {
                    if (id != value)
                    {
                        id = value;
                        OnPropertyChanged(nameof(ID));
                    }
                }
            }
            public string IP
            {
                get { return ip; }
                set
                {
                    if (ip != value)
                    {
                        ip = value;
                        OnPropertyChanged(nameof(ip));
                    }
                }
            }
            public string Cpm1_Ip
            {
                get { return cpm1_Ip; }
                set
                {
                    if (cpm1_Ip != value)
                    {
                        cpm1_Ip = value;
                        OnPropertyChanged(nameof(Cpm1_Ip));
                    }
                }
            }
            public string Cpm2_Ip
            {
                get { return cpm2_Ip; }
                set
                {
                    if (cpm2_Ip != value)
                    {
                        cpm2_Ip = value;
                        OnPropertyChanged(nameof(Cpm2_Ip));
                    }
                }
            }
            public void Set_Property(string str)
            {
                this.Name = str;
                this.ID = str;
                this.Type = str;
                this.IP = str;
            }
            public void Set_Property(string name, string id, string type, string ip)
            {
                this.Name = name;
                this.ID = id;
                this.Type = type;
                this.IP = ip;

            }
            public void Set_Property(string name, string id, string type,string ip, string cpm1_ip,string cpm2_ip)
            {
                this.Name = name;
                this.ID = id;
                this.Type = type;
                this.IP = ip;
                this.Cpm1_Ip = cpm1_ip;
                this.Cpm2_Ip = cpm2_ip;

            }
            public event PropertyChangedEventHandler? PropertyChanged;
            protected virtual void OnPropertyChanged(string propertyName)
            {
                PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            }
        }

    }
}
