﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using static Demo_Viewer.Common.Mediator;
namespace Demo_Viewer.ViewModel
{
    public class Main_ViewModel : ViewModelBase
    {
        public static Top S_Top=new Top();
        public static Configuration_ViewModel S_Configuration_ViewModel = new Configuration_ViewModel();
        public static Monitoring_ViewModel S_Monitoring_ViewModel= new Monitoring_ViewModel();
        public bool Monitoring_State=false;
        // Property 선언
        private string _menuIMG { get; set; }
        public string MenuIMG { get { return _menuIMG; } set { _menuIMG = value; OnPropertyChanged("MenuIMG"); } }
        private string _menuSize { get; set; }
        public string MenuSize { get { return _menuSize; } set { _menuSize = value; OnPropertyChanged("MenuSize"); } }
        private string _date { get; set; }
        public string Date { get { return _date; } set { _date = value; OnPropertyChanged("Date"); } }
        private string _uri_ { get; set; }
        public string Uri_ { get { return _uri_; } set { _uri_ = value; OnPropertyChanged("Uri_"); } }
        private GridValue _g_Value;
        public GridValue G_Value { get { return _g_Value; } set { _g_Value = value; OnPropertyChanged("G_Value"); } }

        // Command 선언 
        public ICommand MenuChangeCommand { get; private set; }
        public ICommand UriChangeCommand { get; private set; }

        public Main_ViewModel()
        {
            Config();
            MenuChangeCommand = new RelayCommad<Object>(MenuChangeCommandMethod);
            UriChangeCommand = new RelayCommad<Object>(UriChangeCommandMethod);
            MenuIMG = "img/SHOW.png";
            MenuSize = "0";
            Uri_ = "Home/Home_Page.xaml";
            Date = DateTime.Now.ToString("yyyy.MM.dd");
            Register("Change_Uri", UriChangeCommandMethod);
            Register("Change_Grid", Change_Grid);
            G_Value = new GridValue("auto", "4*", "*");
        }
        private void Config()
        {
        }

        public void Change_Grid(object obj)
        {
            if (obj as string == "START")
                G_Value.SetValue("0", "*", "0");
                
            
            else if (obj as string == "STOP")
                G_Value.SetValue("auto", "4*", "*");
                
            
                
        }
        private void MenuChangeCommandMethod(object parameter)
        {
            if (MenuSize == "0")
            {
                MenuIMG = "img/HIDE.png";
                MenuSize = "120";
            }
            else
            {
                MenuIMG = "img/SHOW.png";
                MenuSize = "0";
            }
        }
        private void UriChangeCommandMethod(object parameter)
        {
            string str = parameter as string;
            NotifyColleagues("Xml_Visibility_Change", "Hidden");
            switch (str)
            {
                
                case ("Home"):
                    Uri_ = "Home/Home_Page.xaml";
                    break;
                case ("Monitoring"):
                    Uri_ = "Monitoring/SystemView/Cabinet_Level_Page.xaml";
                    break;
                case ("Configuration"):
                    Uri_ = "Configuration/Configuration_Page.xaml";
                    NotifyColleagues("Xml_Visibility_Change", "Visible");
                    NotifyColleagues("ReSet_Pick_Cabinet", "");
                    break;
                case ("Range"):
                    Uri_ = "Range/Range_Page.xaml";
                    break;
                case ("Cabinet_Level_Page"):
                    Uri_ = "Monitoring/SystemView/Cabinet_Level_Page.xaml";
                    
                    break;
                case ("Rack_Level_Page"):
                    Uri_ = "Monitoring/SystemView/Rack_Level_Page.xaml";
                    
                    break;
                case ("MenuGrid"):
                    if (MenuSize == "0")
                    {
                        MenuIMG = "img/HIDE.png";
                        MenuSize = "120";
                    }
                    else
                    {
                        MenuIMG = "img/SHOW.png";
                        MenuSize = "0";
                    }
                    break;
            }
        }
        
    }
        
}
