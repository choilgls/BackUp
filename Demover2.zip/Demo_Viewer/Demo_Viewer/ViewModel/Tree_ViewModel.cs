﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using static Demo_Viewer.ViewModel.Main_ViewModel;
using static Demo_Viewer.Common.Mediator;
using Microsoft.Win32;
using System.IO;

namespace Demo_Viewer.ViewModel
{
    public class Tree_ViewModel : ViewModelBase
    {
     
        XmlHelper xmlHelper;
        private string _icon { get; set; }
        public string Icon { get { return _icon; } set { _icon = value; OnPropertyChanged("Icon"); } }
        private string _height { get; set; }
        public string Height { get { return _height; } set { _height = value; OnPropertyChanged("Height"); } }
        private string xml_Visibility { get; set; }
        public string Xml_Visibility { get { return xml_Visibility; } set { xml_Visibility = value; OnPropertyChanged("Xml_Visibility"); } }
        public ICommand IconTopCommand { get; private set; }
        public ICommand itemClickCommand { get; private set; }
        public ICommand Xml_ImportCommand { get; private set; }
        public ICommand Xml_ExportCommand { get; private set; }
        protected bool _visible { get; set; }
        private EWS ews_ { get; set; }
        public EWS EWS_ { get { return ews_; } set { ews_ = value; OnPropertyChanged("EWS_"); } }
        private ObservableCollection<Cabinet> cabinets { get; set; }
        public ObservableCollection<Cabinet> Cabinets
        {
            get { return cabinets; }
            set
            {
                if (cabinets != value)
                {
                    cabinets = value;
                    OnPropertyChanged(nameof(Cabinets));
                }
            }
        }

        public Tree_ViewModel()
        {
            EWS_ = S_Top.EWS_;
            Cabinets = S_Top.Cabinets;
            IconTopCommand = new RelayCommad<Object>(ClickTopCommandMethod);
            itemClickCommand = new RelayCommad<Object>(itemClickCommandMethod);
            Xml_ImportCommand = new RelayCommad<Object>(Xml_ImportCommandMethod);
            Xml_ExportCommand = new RelayCommad<Object>(Xml_ExportCommandMethod);
            Icon = "▼";
            _visible = true;
            Height = "auto";
            xmlHelper= new XmlHelper();
            Register("Xml_Visibility_Change", Xml_Visibility_Change);
            Xml_Visibility_Change("Hidden");
        }
        public void Xml_Visibility_Change(object obj)
        {
            if(obj is not null)
                Xml_Visibility = obj as string;
        }
        private void Xml_ImportCommandMethod(object parameter)
        {
            OpenFileDialog dlgOpenFile=new OpenFileDialog();
            dlgOpenFile.Filter = "Xml files (*.xml)|*.xml;|All files (*.*)|*.*";
            if (S_Top.Cabinets.Count > 0)
            {
                if (MessageBox.Show("외부 파일을 가져오시겠습니까?\n(입력한 정보는 모두 삭제 됩니다.)", "타이틀", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    S_Top.Cabinets.Clear();
                }
            }
            if (dlgOpenFile.ShowDialog().ToString() == "True")
            {
                if (Path.GetExtension(dlgOpenFile.FileName) == ".xml")
                {
                    xmlHelper.XmlRead(dlgOpenFile.FileName);
                    Cabinets = S_Top.Cabinets;
                    NotifyColleagues("ReSet_Pick_Cabinet", "");
                }
            }

        }
        private void Xml_ExportCommandMethod(object parameter)
        {
            SaveFileDialog dlgSave=new SaveFileDialog();

            dlgSave.Filter = "*.xml|*.xml;";
            dlgSave.Title = "Save an Excel File";
            if (dlgSave.ShowDialog().ToString() == "True")
            {
                if (Path.GetExtension(dlgSave.FileName) == ".xml")
                    xmlHelper.XmlWrite(dlgSave.FileName);
                    //MessageBox.Show(dlgSave.FileName);
            }
        }
        private void itemClickCommandMethod(object parameter)
        {
            NotifyColleagues("Config", "TOP");
        }

        private void ClickTopCommandMethod(object parameter)
        {
            if (!_visible)
            {
                _visible=true;
                Icon = "▼";
                Height = "auto";
            }
            else
            {
                _visible = false;
                Icon = "▶";
                Height = "0";
            }
                
        }

    }
}
