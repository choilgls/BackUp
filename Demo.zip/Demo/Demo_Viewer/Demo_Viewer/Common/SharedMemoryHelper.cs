﻿using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Markup;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using static Demo_Viewer.Common.Mediator;
using static Demo_Viewer.Common.ProcessHelper;
using static Demo_Viewer.ViewModel.Main_ViewModel;
namespace Demo_Viewer.Common
{
    public class SharedMemoryHelper
    {
        static public string S_Message = "";
        private Task get_Task;
        private Task set_Task;
        private CancellationTokenSource cancelTokenSource;
        public SharedMemoryHelper()
        {
            
        }
        public void Get()
        {
            cancelTokenSource = new CancellationTokenSource();
            get_Task = Task.Run(() => HandleGetInfo(cancelTokenSource.Token));
            set_Task = Task.Run(() => HandleSetInfo(cancelTokenSource.Token));

        }
        public void Delete()
        {
            cancelTokenSource.Cancel();
            System.Console.WriteLine("Task .....");
            Task.WaitAll(get_Task, set_Task);
            System.Console.WriteLine("Task exit");

        }
        private async Task HandleGetInfo(CancellationToken cancellationToken)
        {

            string previousMessage = string.Empty;

            while (true)
            {
                //MessageBox.Show(previousMessage);
                try
                {
                    using (var mmf = MemoryMappedFile.OpenExisting("TestBuilderGet"))
                    {

                        using (var accessor = mmf.CreateViewAccessor())
                        {
                            byte[] buffer = new byte[1000];
                            accessor.ReadArray<byte>(0, buffer, 0, buffer.Length);
                            string newMessage = Encoding.ASCII.GetString(buffer).Trim('\0');
                            //Console.WriteLine(newMessage);
                            if (newMessage != previousMessage)
                            {
                                previousMessage = newMessage;
                                Task CPMSet_Task = Task.Run(() => CPMState_Change(newMessage));
                                Task IOMSet_Task = Task.Run(() => IOMState_Change(newMessage));

                                //System.Console.WriteLine("newMessage : "+newMessage);
                                //NotifyColleagues("ADDLOG", "Log!@# SharedMemory Get Data :" + newMessage);


                            }
                            if (cancellationToken.IsCancellationRequested)

                            {

                                return;

                            }

                        }
                    }
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show(" TestBuilder does not exist.\n wait...");
                    PH.KillProcess();
                    PH.StartProcess();
                    Thread.Sleep(3000);
                }
                Thread.Sleep(500);
            }
        }
        private async Task IOMState_Change(string message)
        {
            //System.Console.WriteLine("newMessage : " + message);
            foreach (Cabinet ca in S_Top.Cabinets)
            {
                foreach (Rack rack in ca.Racks)
                {
                    foreach (IOM iom in rack.IOMs)
                    {
                        DispatcherService.Invoke((System.Action)(() =>
                        {
                            iom.Bgr_Color = "Gray";
                            iom.State = false;
                            iom.Monitoring_Data.Data1 = "0";
                            iom.Monitoring_Data.Data2 = "0";
                            iom.Monitoring_Data.Data3 = "0";
                        }));
                    }
                        /*if (message == "")
                        {                       
                            foreach (IOM iom in rack.IOMs)
                            {

                                DispatcherService.Invoke((System.Action)(() =>
                                {
                                    iom.Bgr_Color = "Gray";
                                    iom.State = false;
                                }));

                            }
                        }*/
                        //else
                        //{
                        foreach (IOM iom in rack.IOMs)
                        {
                            string[] split_cpmmessage = message.Split("<<");
                            for(int i=0;i<split_cpmmessage.Count()-1; i++)
                            {
                                if (split_cpmmessage[i].Contains(iom.IP))
                                {
                                    string[] split_iommessage = split_cpmmessage[i].Split(">>");
                                    for (int j = 1; j < split_iommessage[j].Count() - 1; j++)
                                    {
                                        if (split_iommessage[j].Contains(iom.IP))
                                        {
                                            DispatcherService.Invoke((System.Action)(() =>
                                            {
                                                iom.Bgr_Color = "SkyBlue";
                                                iom.State = true;
                                                string[] data = split_iommessage[j].Split(";");
                                                iom.Monitoring_Data.Data1=data[1];
                                                iom.Monitoring_Data.Data2=data[2];
                                                iom.Monitoring_Data.Data3=data[3];
                                            }));
                                        }                                        
                                    }
                                }
                               
                            }

                        }
                   // }
                }

            }
        }
        private async Task CPMState_Change(string message)
        {
            System.Console.WriteLine("newMessage : " + message);
            foreach (Cabinet ca in S_Top.Cabinets)
            {
                foreach (Rack rack in ca.Racks)
                {
                    if (message == "")
                    {
                        foreach (CPM cpm in rack.CPMs)
                        {
                           
                                DispatcherService.Invoke((System.Action)(() =>
                                {
                                    cpm.M_B_State = "-";
                                    cpm.Bgr_Color = "Gray";
                                    cpm.State = false;
                                }));
                            
                        }
                    }
                    else
                    {
                        foreach (CPM cpm in rack.CPMs)
                        {
                            string[] split_cpmmessage = message.Split("<<");
                            for (int i = 0; i < split_cpmmessage.Count() - 1; i++)
                            {
                                if (split_cpmmessage[i].Contains(cpm.IP))
                                {
                                    string[] split_iommessage = split_cpmmessage[i].Split(">>");
                                    
                                    DispatcherService.Invoke((System.Action)(() =>
                                    {
                                        if (split_iommessage[0].Split(";")[1] == "0")
                                            cpm.M_B_State = "Main";
                                        else if(split_iommessage[0].Split(";")[1] == "1")
                                            cpm.M_B_State = "BackUp";
                                        cpm.Bgr_Color = "OrangeRed";
                                        cpm.State = true;
                                    }));
                                    break;
                                }
                                else
                                {
                                    DispatcherService.Invoke((System.Action)(() =>
                                    {
                                        cpm.Bgr_Color = "Gray";
                                        cpm.State = false;
                                    }));
                                    
                                }
                            }

                        }
                    }
                }

            }
        }


        private async Task HandleSetInfo(CancellationToken cancellationToken)
        {

            while (true)
            {
                string previousMessage = string.Empty;
                //MessageBox.Show(previousMessage);
                try
                {
                    using (var mmf = MemoryMappedFile.OpenExisting("TestBuilderSet", MemoryMappedFileRights.ReadWrite))
                    {

                        using (var accessor = mmf.CreateViewAccessor())
                        {
                            while (true)
                            {
                                string Message = string.Empty;
                                Message = S_Message;
                                
                                byte[] buffer = Encoding.ASCII.GetBytes(Message);
                                if (buffer.Length != accessor.Capacity)
                                {
                                    byte[] resetBuffer = new byte[accessor.Capacity];
                                    accessor.WriteArray<byte>(0, resetBuffer, 0, resetBuffer.Length);
                                    accessor.WriteArray<byte>(0, buffer, 0, buffer.Length);
                                }
                                else
                                {
                                    accessor.WriteArray<byte>(0, buffer, 0, buffer.Length);
                                }

                                System.Console.WriteLine($"Sent message: {Message}");
                                System.Threading.Thread.Sleep(1000);
                                if (cancellationToken.IsCancellationRequested)

                                {

                                    return;

                                }
                            }

                        }
                    }
                }
                catch (FileNotFoundException)
                {
                    MessageBox.Show("Set TestBuilder does not exist.\n wait...");
                    //PH.KillProcess();
                    // PH.StartProcess();
                    Thread.Sleep(3000);
                }
                Thread.Sleep(500);
            }
        }


    }
}
