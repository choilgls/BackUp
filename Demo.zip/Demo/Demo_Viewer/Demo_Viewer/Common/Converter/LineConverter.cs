﻿using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Data;
using static Demo_Viewer.ViewModel.Main_ViewModel;

namespace Demo_Viewer.Common.Converter
{
    internal class LineConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            Top top=S_Top;
            if(parameter == null)
            {
                return value;
            }
            string str = parameter as string;
            double size = System.Convert.ToDouble(value);
            if (str.Contains('-'))
            {
                int param = S_Top.Cabinets.Count() * 2;
                return size / param;
            }
            else if (str.Contains('+'))
            {
                int param = S_Top.Cabinets.Count()*2;
                return (size / param )*(param-1);
            }
            else if (str.Contains('/'))
            {
                int param = S_Top.Cabinets.Count();
                return (size / param);
            }
            else
            {
                double param = System.Convert.ToDouble(parameter);
                return size / param;
            }
            

            
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
