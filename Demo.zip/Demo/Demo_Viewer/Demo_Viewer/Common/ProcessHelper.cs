﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Diagnostics;


namespace Demo_Viewer.Common
{
    public class ProcessHelper
    {
        static public ProcessHelper PH = new ProcessHelper();
        string ProcessName = String.Empty;
        string ProcessAllPath = String.Empty;
        public ProcessHelper()
        {
            ProcessName = "Agent";
            ProcessAllPath = "C:\\works\\Demo\\Sample2\\Sample1\\bin\\Debug\\net6.0-windows\\Sample1.exe";
            
        }
        public bool CheckProcess()
        {
            Process[] processes = Process.GetProcessesByName(this.ProcessName);
            if (processes.Length == 0)
                return false;
            return true;
        }
        public void KillProcess()
        {
            Process[] processes = Process.GetProcessesByName(this.ProcessName);

            foreach (Process process in processes)
            {
                process.Kill();
                process.WaitForExit();
            }
        }
        public void StartProcess( string arguments = "")
        {
            ProcessStartInfo startInfo = new ProcessStartInfo()
            {
                FileName = this.ProcessAllPath,
                Arguments = arguments
            };

            Process process = new Process()
            {
                StartInfo = startInfo
            };

            process.Start();
        }
    }
}
