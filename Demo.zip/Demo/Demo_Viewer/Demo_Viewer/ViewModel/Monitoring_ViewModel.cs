﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Demo_Viewer.ViewModel.Main_ViewModel;
using static Demo_Viewer.Common.Mediator;
using static Demo_Viewer.Common.SharedMemoryHelper;
using Microsoft.Win32;
using System.Windows.Input;
using System.Windows;
using Demo_Viewer.View.Setting;
using System.Threading;

namespace Demo_Viewer.ViewModel
{

    public class Monitoring_ViewModel : ViewModelBase
    {
        SharedMemoryHelper sharedMemoryHelper = new SharedMemoryHelper();
        Setting_Window window ;
        private Top top_ { get; set; }
        public Top Top_ { get { return top_; } set { top_ = value; OnPropertyChanged("Top_"); } }

        private Cabinet pick_Cabinet { get; set; }
        public Cabinet Pick_Cabinet { get { return pick_Cabinet; } set { pick_Cabinet = value; OnPropertyChanged("Pick_Cabinet"); } }
        private Rack pick_Rack { get; set; }
        public Rack Pick_Rack { get { return pick_Rack; } set { pick_Rack = value; OnPropertyChanged("Pick_Rack"); } }
        private CPM pick_CPM { get; set; }
        public CPM Pick_CPM { get { return pick_CPM; } set { pick_CPM = value; OnPropertyChanged("Pick_CPM"); } }
        private IOM pick_IOM { get; set; }
        public IOM Pick_IOM { get { return pick_IOM; } set { pick_IOM = value; OnPropertyChanged("Pick_IOM"); } }

        private string iom_Visibility { get; set; }
        public string Iom_Visibility { get { return iom_Visibility; } set { iom_Visibility = value; OnPropertyChanged("Iom_Visibility"); } }
        private string cpm_Visibility { get; set; }
        public string Cpm_Visibility { get { return cpm_Visibility; } set { cpm_Visibility = value; OnPropertyChanged("Cpm_Visibility"); } }
        private string default_Visibility { get; set; }
        public string Default_Visibility { get { return default_Visibility; } set { default_Visibility = value; OnPropertyChanged("Default_Visibility"); } }

        private string data1_img { get; set; }
        public string Data1_img { get { return data1_img; } set { data1_img = value; OnPropertyChanged("Data1_img"); } }
        private string data2_img { get; set; }
        public string Data2_img { get { return data2_img; } set { data2_img = value; OnPropertyChanged("Data2_img"); } }
        private string data3_img { get; set; }
        public string Data3_img { get { return data3_img; } set { data3_img = value; OnPropertyChanged("Data3_img"); } }

        private string rack_Text_Visibility { get; set; }
        public string Rack_Text_Visibility { get { return rack_Text_Visibility; } set { rack_Text_Visibility = value; OnPropertyChanged("Rack_Text_Visibility "); } }
        private string img_Monitoring_Button { get; set; }
        public string Img_Monitoring_Button { get { return img_Monitoring_Button; } set { img_Monitoring_Button = value; OnPropertyChanged("Img_Monitoring_Button"); } }
        private string img_Setting_Button_Visibility { get; set; }
        public string Img_Setting_Button_Visibility { get { return img_Setting_Button_Visibility; } set { img_Setting_Button_Visibility = value; OnPropertyChanged("Img_Setting_Button_Visibility"); } }
        private bool Monitoring_State = false;

        public ICommand Img_Monitoring_ButtonCommand { get; private set; }
        public ICommand Change_UriCommand { get; private set; }
        public ICommand SettingWindowCommand { get; private set; }
        public ICommand SetCommand { get; private set; }
        public ICommand SwitchCommand { get; private set; }

        private Rack Empty_Rack = new Rack("N/A", "N/A");
        private Cabinet Empty_Cabinet = new Cabinet("N/A", "N/A");
        private CPM Empty_CPM = new CPM("N/A", "N/A", "N/A");
        private IOM Empty_IOM = new IOM("N/A", "N/A", "N/A", "N/A", "N/A");


        public Monitoring_ViewModel()
        {
            Top_ = S_Top;
            Register("Set_Pick_Cabinet", Set_Pick_Cabinet);
            Register("ReSet_Pick_Cabinet", ReSet_Pick_Cabinet);
            Register("Set_Pick_Rack", Set_Pick_Rack);
            Register("Set_Pick_CPM", Set_Pick_CPM);
            Register("Set_Pick_IOM", Set_Pick_IOM);
            Pick_Cabinet = Empty_Cabinet;
            Pick_Rack = Empty_Rack;
            Pick_CPM = Empty_CPM;
            Pick_IOM = Empty_IOM;
            Pick_Rack = Empty_Rack;
            Img_Monitoring_Button = "../../img/START.png";
            Set_Visibility("Visible", "Hidden", "Hidden");
            Img_Setting_Button_Visibility = "Hidden";
            Img_Monitoring_ButtonCommand = new RelayCommad<Object>(Img_Monitoring_ButtonCommandMethod);
            Change_UriCommand = new RelayCommad<Object>(Change_UriCommandMethod);
            SettingWindowCommand = new RelayCommad<Object>(SettingWindowCommandMethod);
            SetCommand = new RelayCommad<Object>(SetCommandMethod);
            SwitchCommand = new RelayCommad<Object>(SwitchCommandMethod);
            Set_Width("48", "37");
            
        }

        private void SetCommandMethod(object parameter)
        {
            string data1 = string.Empty;
            string data2 = string.Empty;
            string data3 = string.Empty;
            if (Data1_img == "../img/OFFSWITCH.png")
                data1 = "0";
            else
                data1 = "1";

            if (Data2_img == "../img/OFFSWITCH.png")
                data2 = "0";
            else
                data2 = "1";

            if (Data3_img == "../img/OFFSWITCH.png")
                data3 = "0";
            else
                data3 = "1";
            /*if (Pick_Rack.CPMs.Count == 1)
            {
                SharedMemoryHelper.S_Message = Pick_Rack.CPMs[0].IP+"->" + Pick_IOM.IP+">>"+ data1+";" + data2 + ";" + data3;
                
            }
            else if(Pick_Rack.CPMs.Count == 2)
            {
                SharedMemoryHelper.S_Message = Pick_Rack.CPMs[0].IP+","+ Pick_Rack.CPMs[1].IP + "->" + Pick_IOM.IP + ">>" + data1 + ";" + data2 + ";" + data3;
            }*/
            SharedMemoryHelper.S_Message = Pick_IOM.Cpm1_Ip + "," + Pick_IOM.Cpm2_Ip + "->" + Pick_IOM.IP + ">>" + data1 + ";" + data2 + ";" + data3;
            Thread.Sleep(300);
        }
        private void SwitchCommandMethod(object parameter)
        {
            string str = parameter as string;
            switch (str)
            {
                case "1":
                    if (Data1_img == "../img/OFFSWITCH.png")
                        Data1_img = "../img/REDSWITCH.png";
                    else
                        Data1_img = "../img/OFFSWITCH.png";
                    break;
                case "2":
                    if (Data2_img == "../img/OFFSWITCH.png")
                        Data2_img = "../img/BLUESWITCH.png";
                    else
                        Data2_img = "../img/OFFSWITCH.png";
                    break;
                case "3":
                    if (Data3_img == "../img/OFFSWITCH.png")
                        Data3_img = "../img/GREENSWITCH.png";
                    else
                        Data3_img = "../img/OFFSWITCH.png";
                    break;
            }
        }
        private void SettingWindowCommandMethod(object parameter)
        {
            Data1_img = "../img/OFFSWITCH.png";
            Data2_img = "../img/OFFSWITCH.png";
            Data3_img = "../img/OFFSWITCH.png";
            if (Pick_IOM.Monitoring_Data.Data1 != "0")
                Data1_img = "../img/REDSWITCH.png";

            if (Pick_IOM.Monitoring_Data.Data2 != "0")
                Data2_img = "../img/BLUESWITCH.png";

            if (Pick_IOM.Monitoring_Data.Data3 != "0")
                Data3_img = "../img/GREENSWITCH.png";
            window =new Setting_Window();
            window.ShowDialog();
        }
        private void Change_UriCommandMethod(object parameter)
        {
            NotifyColleagues("Change_Uri", "Cabinet_Level_Page");
        }
        private void Img_Monitoring_ButtonCommandMethod(object parameter)
        {
            if (S_Top.Cabinets.Count <= 0)
            {
                MessageBox.Show("시스템 형상 먼저 등록하시오.");
                return;
            }
            if (Img_Monitoring_Button == "../../img/START.png")
            {
                if (MessageBox.Show("모니터링 모드로 전환하시겠습니까?", "타이틀", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    sharedMemoryHelper.Get();
                    Img_Monitoring_Button = "../../img/STOP.png";
                    Set_Width("90", "52");
                    NotifyColleagues("Change_Grid", "START");
                    Img_Setting_Button_Visibility = "Visible";
                }

            }
            else
            {
                if (MessageBox.Show("모니터링 모드를 해제하시겠습니까?", "타이틀", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    sharedMemoryHelper.Delete();
                    Img_Monitoring_Button = "../../img/START.png";
                    Set_Width("48", "37");
                    NotifyColleagues("Change_Grid", "STOP");
                    Img_Setting_Button_Visibility = "Hidden";
                }

            }

        }

        public void Set_Width(string cpm, string iom)
        {
            foreach (Cabinet ca in S_Top.Cabinets)
            {
                foreach (Rack rack in ca.Racks)
                {
                    rack.Cpm_Width = cpm;
                    rack.Iom_Width = iom;
                }
            }

        }
        public void Set_Visibility(string default_, string cpm, string iom)
        {
            Default_Visibility = default_;
            Cpm_Visibility = cpm;
            Iom_Visibility = iom;
            Rack_Text_Visibility = "Hidden";
        }
        public void ReSet_Pick_Cabinet(object obj)
        {
            Pick_Cabinet = Empty_Cabinet;
            Rack_Text_Visibility = "Visible";
        }
        public void Set_Pick_Cabinet(object obj)
        {
            Pick_Cabinet = obj as Cabinet;
            Set_Visibility("Visible", "Hidden", "Hidden");
        }
        public void Set_Pick_Rack(object obj)
        {
            Pick_Rack = obj as Rack;
            Set_Visibility("Visible", "Hidden", "Hidden");
        }
        public void Set_Pick_CPM(object obj)
        {
            Pick_CPM = obj as CPM;
            foreach (Cabinet ca in S_Top.Cabinets)
            {
                foreach (Rack ra in ca.Racks)
                {
                    foreach (CPM cpm in ra.CPMs)
                    {
                        if (cpm.ID == Pick_CPM.ID)
                        {
                            Pick_Rack = ra;
                            Set_Visibility("Hidden", "Visible", "Hidden");
                            return;
                        }
                    }
                }
            }

        }
        public void Set_Pick_IOM(object obj)
        {
            Pick_IOM = obj as IOM;
            foreach (Cabinet ca in S_Top.Cabinets)
            {
                foreach (Rack ra in ca.Racks)
                {
                    foreach (IOM iom in ra.IOMs)
                    {
                        if (iom.ID == Pick_IOM.ID)
                        {
                            Pick_Rack = ra;
                            Set_Visibility("Hidden", "Hidden", "Visible");

                            return;
                        }
                    }
                }
            }

        }

    }
}
