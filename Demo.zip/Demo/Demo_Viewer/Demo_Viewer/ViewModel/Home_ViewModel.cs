﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using static Demo_Viewer.Model.User;
using static Demo_Viewer.Common.Mediator;
namespace Demo_Viewer.ViewModel
{
    public class Home_ViewModel : ViewModelBase
    {
        public ICommand UriChangeCommand { get; private set; }
        public string Content { get; set; }
        public User UserInfo { get; set; }
        public Home_ViewModel()
        {
            UserInfo = user;
            Content = "안녕하세요. " + UserInfo.Name + " " + UserInfo.Rank + "님.";
            UriChangeCommand = new RelayCommad<Object>(UriChangeCommandMethod);
        }
        private void UriChangeCommandMethod(object parameter)
        {
            NotifyColleagues("Change_Uri", "Configuration");
        }

    }
}
