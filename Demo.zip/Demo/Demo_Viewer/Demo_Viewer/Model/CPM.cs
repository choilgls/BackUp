﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Viewer.Model
{
    public class CPM: INotifyPropertyChanged
    {
        public CPM()
        {
            Name = "";
            ID = "";
            IP = "";
            Bgr_Color = "Gray";
            State = false;
            M_B_State = "-";
            Monitoring_Data = new CPM_Monitoring_Data();
        }
        public CPM(string name, string id , string ip)
        {
            Name = name;
            ID = id;
            IP = ip;
            Bgr_Color = "Gray";
            State = false;
            M_B_State = "-";
            Monitoring_Data = new CPM_Monitoring_Data();
        }


        public CPM_Monitoring_Data Monitoring_Data
        {
            get { return monitoring_Data; }
            set
            {
                if (monitoring_Data != value)
                {
                    monitoring_Data = value;
                    OnPropertyChanged(nameof(Monitoring_Data));
                }
            }
        }
        private CPM_Monitoring_Data monitoring_Data { get; set; }

        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        public string ID
        {
            get { return iD; }
            set
            {
                if (iD != value)
                {
                    iD = value;
                    OnPropertyChanged(nameof(ID));
                }
            }
        }
        public string IP
        {
            get { return iP; }
            set
            {
                if (iP != value)
                {
                    iP = value;
                    OnPropertyChanged(nameof(IP));
                }
            }
        }

        public string Bgr_Color
        {
            get { return bgr_Color; }
            set
            {
                if (bgr_Color != value)
                {
                    bgr_Color = value;
                    OnPropertyChanged(nameof(Bgr_Color));
                }
            }
        }

        public string M_B_State
        {
            get { return m_B_State; }
            set
            {
                if (m_B_State != value)
                {
                    m_B_State = value;
                    OnPropertyChanged(nameof(M_B_State));
                }
            }
        }

        public bool State
        {
            get { return state; }
            set
            {
                if (state != value)
                {
                    state = value;
                    OnPropertyChanged(nameof(State));
                }
            }
        }
        public string SlotIndex
        {
            get { return slotIndex; }
            set
            {
                if (slotIndex != value)
                {
                    slotIndex = value;
                    OnPropertyChanged(nameof(SlotIndex));
                }
            }
        }

        private string name { get; set; }
        private string iP { get; set; }
        private string iD { get; set; }
        private string m_B_State { get; set; }
        private int rackNumber { get; set; }
        private string slotIndex { get; set; }
        private bool state { get; set; }
        private string bgr_Color{ get; set; }
        private bool active { get; set; }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

    }
    public class CPM_Monitoring_Data : INotifyPropertyChanged
    {
        public CPM_Monitoring_Data()
        {
            OS = "Data - 1";
            BIT = "정상";
            MainBackUp = "Main";
            ActiveStanBy = "Active";
        }

        public string OS
        {
            get { return os; }
            set
            {
                if (os != value)
                {
                    os = value;
                    OnPropertyChanged(nameof(OS));
                }
            }
        }
        public string BIT
        {
            get { return bIT; }
            set
            {
                if (bIT != value)
                {
                    bIT = value;
                    OnPropertyChanged(nameof(BIT));
                }
            }
        }
        public string ActiveStanBy
        {
            get { return activeStanBy; }
            set
            {
                if (activeStanBy != value)
                {
                    activeStanBy = value;
                    OnPropertyChanged(nameof(ActiveStanBy));
                }
            }
        }
        public string MainBackUp
        {
            get { return mainBackUp; }
            set
            {
                if (mainBackUp != value)
                {
                    mainBackUp = value;
                    OnPropertyChanged(nameof(MainBackUp));
                }
            }
        }
        private string os { get; set; }
        private string bIT { get; set; }
        private string activeStanBy { get; set; }
        private string mainBackUp { get; set; }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
