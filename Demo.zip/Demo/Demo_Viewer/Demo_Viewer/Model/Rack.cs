﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls.Primitives;

namespace Demo_Viewer.Model
{
    public class Rack : INotifyPropertyChanged
    {
        public Rack()
        {
            Name = "";
            ID = "";
            CPMs = new ObservableCollection<CPM>();
            IOMs = new ObservableCollection<IOM>();
            C_Num = 1;
            Cpm_Width = "48";
            Iom_Width = "37";
            I_Num = 2;
        }
        public Rack(string name, string id)
        {
            Name = name;
            ID = id;
            CPMs = new ObservableCollection<CPM>();
            IOMs = new ObservableCollection<IOM>();
            C_Num = 1;
            Cpm_Width = "48";
            Iom_Width = "37";
            I_Num = 2;
        }   


        public void AddCPM(string name,string id,string ip)
        {
            CPMs.Add(new CPM(name, id,ip));
            C_Num++;
        }
        public void AddIOM(string name, string id,string ip,string cpm1_ip,string cpm_2ip)
        {
            IOMs.Add(new IOM(name, id,ip,cpm1_ip,cpm_2ip));
            I_Num++;
        }


        public ObservableCollection<CPM> CPMs
        {
            get { return cPMs; }
            set
            {
                if (cPMs != value)
                {
                    cPMs = value;
                    OnPropertyChanged(nameof(CPMs));
                }
            }
        }
        public ObservableCollection<IOM> IOMs
        {
            get { return iOMs; }
            set
            {
                if (iOMs != value)
                    iOMs = value;
                OnPropertyChanged(nameof(IOMs));
            }  
        }
        public int C_Num { get; set; }
        public int I_Num { get; set; }
        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        public string ID
        {
            get { return iD; }
            set
            {
                if (iD != value)
                {
                    iD = value;
                    OnPropertyChanged(nameof(ID));
                }
            }
        }


        private string name { get; set; }
        private string iD { get; set; }
        private int be_Info { get; set; }
        private bool state { get; set; }
        private ObservableCollection<CPM> cPMs { get; set; }
        private ObservableCollection<IOM> iOMs { get; set; }
        private string iom_Width { get; set; }
        public string Iom_Width { get { return iom_Width; } set { iom_Width = value; OnPropertyChanged("Iom_Width"); } }
        private string cpm_Width { get; set; }
        public string Cpm_Width { get { return cpm_Width; } set { cpm_Width = value; OnPropertyChanged("Cpm_Width"); } }


        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
