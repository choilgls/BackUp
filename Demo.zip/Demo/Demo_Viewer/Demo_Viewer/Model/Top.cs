﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo_Viewer.Model
{
    public class Top: INotifyPropertyChanged
    {
        private ObservableCollection<Cabinet> cabinets { get; set; }
        public ObservableCollection<Cabinet> Cabinets
        {
            get { return cabinets; }
            set
            {
                if (cabinets != value)
                {
                    cabinets = value;
                    OnPropertyChanged(nameof(Cabinets));
                }
            }
        }
        private EWS ews_ { get; set; }
        public EWS EWS_
        {
            get { return ews_; }
            set
            {
                if (ews_ != value)
                {
                    ews_ = value;
                    OnPropertyChanged(nameof(EWS_));
                }
            }
        }
        private string name { get; set; }
        public string Name {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        public Top()
        {
            Name = "TOP";
            Cabinets=new ObservableCollection<Cabinet>();
            Num = 1;
            EWS_ = new EWS("EWS", "EWS","10.20.30.100");
        }

        public void AddCabinet(string name,string id)
        {
            Cabinets.Add(new Cabinet( name, id));
            Num++;
        }
        public int Num { get; set; }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
