﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Markup;

namespace Demo_Viewer.Model
{
    public class IOM: INotifyPropertyChanged
    {
        public IOM()
        {
            this.Name = "";
            this.ID = "";
            this.IP = "";
            this.Bgr_Color = "Gray";
            this.State = false;
            this.Cpm1_Ip = "";
            this.Cpm2_Ip = "";
            this.Monitoring_Data = new IOM_Monitoring_Data();
        }
        public IOM(string name, string id,string ip,string cpm1_ip,string cpm2_ip)
        {
            this.Name = name;
            this.ID = id;
            this.IP = ip;
            this.Bgr_Color = "Gray";
            this.State = false;
            this.Cpm1_Ip = cpm1_ip;
            this.Cpm2_Ip = cpm2_ip;
            this.Monitoring_Data=new IOM_Monitoring_Data();
        }
        public IOM_Monitoring_Data Monitoring_Data
        {
            get { return monitoring_Data; }
            set
            {
                if (monitoring_Data != value)
                {
                    monitoring_Data = value;
                    OnPropertyChanged(nameof(Monitoring_Data));
                }
            }
        }
        private IOM_Monitoring_Data monitoring_Data { get; set; }
        public string Name
        {
            get { return name; }
            set
            {
                if (name != value)
                {
                    name = value;
                    OnPropertyChanged(nameof(Name));
                }
            }
        }
        public string ID
        {
            get { return iD; }
            set
            {
                if (iD != value)
                {
                    iD = value;
                    OnPropertyChanged(nameof(ID));
                }
            }
        }
        public string IP
        {
            get { return iP; }
            set
            {
                if (iP != value)
                {
                    iP = value;
                    OnPropertyChanged(nameof(IP));
                }
            }
        }
        public string Bgr_Color
        {
            get { return bgr_Color; }
            set
            {
                if (bgr_Color != value)
                {
                    bgr_Color = value;
                    OnPropertyChanged(nameof(Bgr_Color));
                }
            }
        }
        public bool State
        {
            get { return state; }
            set
            {
                if (state != value)
                {
                    state = value;
                    OnPropertyChanged(nameof(State));
                }
            }
        }

        public string Cpm1_Ip
        {
            get { return cpm1_ip; }
            set
            {
                if (cpm1_ip != value)
                {
                    cpm1_ip = value;
                    OnPropertyChanged(nameof(Cpm1_Ip));
                }
            }
        }
        public string Cpm2_Ip
        {
            get { return cpm2_ip; }
            set
            {
                if (cpm2_ip != value)
                {
                    cpm2_ip = value;
                    OnPropertyChanged(nameof(Cpm2_Ip));
                }
            }
        }
        private string name { get; set; }
        private string iP { get; set; }
        private string iD { get; set; }
        private int rackNumber { get; set; }
        private int index { get; set; }
        private bool state { get; set; }
        private string bgr_Color { get; set; }
        private string cpm1_ip { get; set; }
        private string cpm2_ip { get; set; }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class IOM_Monitoring_Data : INotifyPropertyChanged
    {
        public IOM_Monitoring_Data()
        {
            Data1 = "0";
            Data2 = "0";
            Data3 = "0";
        }

        public string Data1
        {
            get { return data1; }
            set
            {
                if (data1 != value)
                {
                    data1 = value;
                    if (data1 == "0")
                        Data1_LED = "../../../img/OFFLED.png";
                    else if (data1 == "1")
                        Data1_LED = "../../../img/REDLED.png";
                    OnPropertyChanged(nameof(Data1));
                }
            }
        }
        public string Data2
        {
            get { return data2; }
            set
            {
                if (data2 != value)
                {
                    data2 = value;
                    if (data2 == "0")
                        Data2_LED = "../../../img/OFFLED.png";
                    else if (data2 == "1")
                        Data2_LED = "../../../img/BLUELED.png";
                    OnPropertyChanged(nameof(Data2));
                }
            }
        }
        public string Data3
        {
            get { return data3; }
            set
            {
                if (data3 != value)
                {
                    data3 = value;
                    if (data3 == "0")
                        Data3_LED = "../../../img/OFFLED.png";
                    else if (data3 == "1")
                        Data3_LED = "../../../img/GREENLED.png";
                    OnPropertyChanged(nameof(Data3));
                }
            }
        }

        public string Data1_LED
        {
            get { return data1_LED; }
            set
            {
                if (data1_LED != value)
                {
                    data1_LED = value;
                    
                    OnPropertyChanged(nameof(Data1_LED));
                }
            }
        }
        public string Data2_LED
        {
            get { return data2_LED; }
            set
            {
                if (data2_LED != value)
                {
                    data2_LED = value;
                    OnPropertyChanged(nameof(Data2_LED));
                }
            }
        }
        public string Data3_LED
        {
            get { return data3_LED; }
            set
            {
                if (data3_LED != value)
                {
                    data3_LED = value;                   
                    OnPropertyChanged(nameof(Data3_LED));
                }
            }
        }




        public void  SET_LED(string data)
        {
            if (data1 == "0")
                data1_LED = "../../../img/OFFLED.png";
            else if (data1 == "1")
                data1_LED = "../../../img/REDLED.png";
        }
        private string data1 { get; set; }
        private string data2 { get; set; }
        private string data3 { get; set; }
        private string data1_LED { get; set; }
        private string data2_LED { get; set; }
        private string data3_LED { get; set; }
        public event PropertyChangedEventHandler? PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
