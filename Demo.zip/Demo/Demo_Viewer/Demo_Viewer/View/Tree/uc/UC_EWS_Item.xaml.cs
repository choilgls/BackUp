﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Demo_Viewer.Common.Mediator;

namespace Demo_Viewer.View.Tree.uc
{
    /// <summary>
    /// UC_EWS_Item.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_EWS_Item : UserControl
    {
        public ICommand ItemClickCommand { get; private set; }
        public UC_EWS_Item()
        {
            InitializeComponent();
            ItemClickCommand = new RelayCommad<Object>(ItemClickCommandMethod);
        }
        private void ItemClickCommandMethod(object parameter)
        {
            NotifyColleagues("Config", parameter);
        }

        public static readonly DependencyProperty _EWSProperty = DependencyProperty.Register(
         "_EWS", typeof(EWS), typeof(UC_EWS_Item), new PropertyMetadata(null));
        public EWS _EWS
        {
            get { return (EWS)GetValue(_EWSProperty); }
            set { SetValue(_EWSProperty, value); }
        }
    }
}
