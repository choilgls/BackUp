﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Demo_Viewer.Common.Mediator;

namespace Demo_Viewer.View.Tree.uc
{
    /// <summary>
    /// UC_Cabinet_Item.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_Cabinet_Item : UserControl
    {
        public ICommand ItemClickCommand { get; private set; }
        public ICommand IconCommand { get; private set; }
        protected bool _visible { get; set; }
        
        public UC_Cabinet_Item()
        {
            InitializeComponent();
            ItemClickCommand = new RelayCommad<Object>(ItemClickCommandMethod);
            IconCommand = new RelayCommad<Object>(IconCommandMethod);
            Icon = "▼";
            _visible = true;
            Height = "auto";
        }
        private void ItemClickCommandMethod(object parameter)
        {
            NotifyColleagues("Config", parameter);
            NotifyColleagues("Set_Pick_Cabinet", _Cabinet);
        }
        private void IconCommandMethod(object parameter)
        {
            if (!_visible)
            {
                _visible = true;
                Icon = "▼";
                Height = "auto";
            }
            else
            {
                _visible = false;
                Icon = "▶";
                Height = "0";
            }
        }


        public static readonly DependencyProperty _CabinetProperty = DependencyProperty.Register(
         "_Cabinet", typeof(Cabinet), typeof(UC_Cabinet_Item), new PropertyMetadata(null));
        public Cabinet _Cabinet
        {
            get { return (Cabinet)GetValue(_CabinetProperty); }
            set { SetValue(_CabinetProperty, value); }
        }

        public static readonly DependencyProperty HeightProperty = DependencyProperty.Register(
        "Height", typeof(string), typeof(UC_Cabinet_Item), new PropertyMetadata(string.Empty));
        public string Height
        {
            get { return (string)GetValue(HeightProperty); }
            set { SetValue(HeightProperty, value); }
        } 
        public static readonly DependencyProperty IconProperty = DependencyProperty.Register(
        "Icon", typeof(string), typeof(UC_Cabinet_Item), new PropertyMetadata(string.Empty));
        public string Icon
        {
            get { return (string)GetValue(IconProperty); }
            set { SetValue(IconProperty, value); }
        }
    }
}
