﻿using Demo_Viewer.Common;
using Demo_Viewer.Model;
using Demo_Viewer.View.Tree.uc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using static Demo_Viewer.Common.Mediator;

namespace Demo_Viewer.View.Monitoring.SystemView.uc
{
    /// <summary>
    /// UC_Cabinet_Unit.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class UC_Cabinet_Unit : UserControl
    {
        public ICommand ItemClickCommand { get; private set; }
        public UC_Cabinet_Unit()
        {
            InitializeComponent();
            ItemClickCommand = new RelayCommad<Object>(ItemClickCommandMethod);
        }
        private void ItemClickCommandMethod(object parameter)
        {
            NotifyColleagues("Change_Uri", "Rack_Level_Page");
            NotifyColleagues("Set_Pick_Cabinet", _Cabinet);
        }

        public static readonly DependencyProperty _CabinetProperty = DependencyProperty.Register(
         "_Cabinet", typeof(Cabinet), typeof(UC_Cabinet_Unit), new PropertyMetadata(null));
        public Cabinet _Cabinet
        {
            get { return (Cabinet)GetValue(_CabinetProperty); }
            set { SetValue(_CabinetProperty, value); }
        }
    }
}
