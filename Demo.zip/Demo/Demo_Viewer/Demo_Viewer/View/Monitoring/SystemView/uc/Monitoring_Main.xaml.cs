﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace Demo_Viewer.View.Monitoring.SystemView.uc
{
    /// <summary>
    /// Monitoring_Main.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class Monitoring_Main : UserControl
    {
        public Monitoring_Main()
        {
            InitializeComponent();
        }
        public static readonly DependencyProperty MainProperty = DependencyProperty.Register(
      "Main", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Main
        {
            get { return (string)GetValue(MainProperty); }
            set { SetValue(MainProperty, value); }
        }

        public static readonly DependencyProperty Subject1Property = DependencyProperty.Register(
      "Subject1", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Subject1
        {
            get { return (string)GetValue(Subject1Property); }
            set { SetValue(Subject1Property, value); }
        }

        public static readonly DependencyProperty Subject2Property = DependencyProperty.Register(
     "Subject2", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Subject2
        {
            get { return (string)GetValue(Subject2Property); }
            set { SetValue(Subject2Property, value); }
        }

        public static readonly DependencyProperty Subject3Property = DependencyProperty.Register(
     "Subject3", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Subject3
        {
            get { return (string)GetValue(Subject3Property); }
            set { SetValue(Subject3Property, value); }
        }

        public static readonly DependencyProperty Subject4Property = DependencyProperty.Register(
     "Subject4", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Subject4
        {
            get { return (string)GetValue(Subject4Property); }
            set { SetValue(Subject4Property, value); }
        }

        public static readonly DependencyProperty Subject5Property = DependencyProperty.Register(
     "Subject5", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Subject5
        {
            get { return (string)GetValue(Subject5Property); }
            set { SetValue(Subject5Property, value); }
        }

        public static readonly DependencyProperty Subject6Property = DependencyProperty.Register(
     "Subject6", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Subject6
        {
            get { return (string)GetValue(Subject6Property); }
            set { SetValue(Subject6Property, value); }
        }

         public static readonly DependencyProperty Contents1Property = DependencyProperty.Register(
       "Contents1", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Contents1
        {
            get { return (string)GetValue(Contents1Property); }
            set { SetValue(Contents1Property, value); }
        }
        public static readonly DependencyProperty Contents2Property = DependencyProperty.Register(
       "Contents2", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Contents2
        {
            get { return (string)GetValue(Contents2Property); }
            set { SetValue(Contents2Property, value); }
        }

        public static readonly DependencyProperty Contents3Property = DependencyProperty.Register(
       "Contents3", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Contents3
        {
            get { return (string)GetValue(Contents3Property); }
            set { SetValue(Contents3Property, value); }
        }

        public static readonly DependencyProperty Contents4Property = DependencyProperty.Register(
       "Contents4", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Contents4
        {
            get { return (string)GetValue(Contents4Property); }
            set { SetValue(Contents4Property, value); }
        }

        public static readonly DependencyProperty Contents5Property = DependencyProperty.Register(
       "Contents5", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Contents5
        {
            get { return (string)GetValue(Contents5Property); }
            set { SetValue(Contents5Property, value); }
        }

        public static readonly DependencyProperty Contents6Property = DependencyProperty.Register(
       "Contents6", typeof(string), typeof(Monitoring_Main), new PropertyMetadata(null));
        public string Contents6
        {
            get { return (string)GetValue(Contents6Property); }
            set { SetValue(Contents6Property, value); }
        }



    }
}
