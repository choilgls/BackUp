﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Excel = Microsoft.Office.Interop.Excel;

namespace Reporter
{
    public class ViewModel : ViewModelBase
    {
        public ViewModel()
        {
            Excel.Application application = new Excel.Application();
        }
    }
}
