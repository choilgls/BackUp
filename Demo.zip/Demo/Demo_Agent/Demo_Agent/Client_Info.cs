﻿
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static System.Console;
namespace Demo_Agent
{
    
    public class Client_Info
    {
        public TcpClient Client;
        public string Name;

        public Client_Info(TcpClient client)
        {
            Client = client;
            string ip = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
            WriteLine(ip);
            //Name = client.Client.RemoteEndPoint.ToString().Split(':')[1];
            Name =ip;
           
        }
    }
}
