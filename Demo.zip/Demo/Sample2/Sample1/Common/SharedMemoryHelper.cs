﻿using Sample1.Model;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.IO.MemoryMappedFiles;
using System.Linq;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static Sample1.Common.Mediator;
using static Sample1.Common.Client_Info;
using System.Windows.Markup;

namespace Sample1.Common
{
    public class SharedMemoryHelper
    {
        //static public string Message = string.Empty;
        public SharedMemoryHelper()
        {
        }

        public async void Get()
        {
            await Task.Run(() => HandleGetInfo());
        }
        public async void Set()
        {
            await Task.Run(() => HandleSetInfo());
        }
        private async Task HandleGetInfo()
        {
            using (var mmf = MemoryMappedFile.CreateOrOpen("TestBuilderGet", 1000, MemoryMappedFileAccess.ReadWrite))
            {
                using (var accessor = mmf.CreateViewAccessor())
                {
                    //MessageBox.Show("TestBuilderGet Create");

                    while (true)
                    {
                        string Message = string.Empty;
                        foreach (Client_Info info in client_Infos)
                        {
                            Message = Message + info.Message + "<<";
                        }
                        
                        byte[] buffer = Encoding.ASCII.GetBytes(Message);
                        if (buffer.Length != accessor.Capacity)
                        {
                            byte[] resetBuffer = new byte[accessor.Capacity];
                            accessor.WriteArray<byte>(0, resetBuffer, 0, resetBuffer.Length);
                            accessor.WriteArray<byte>(0, buffer, 0, buffer.Length);
                        }
                        else
                        {
                            accessor.WriteArray<byte>(0, buffer, 0, buffer.Length);
                        }

                        NotifyColleagues("ADDLOG", Message);

                        //Console.WriteLine($"Sent message: {message}");
                        System.Threading.Thread.Sleep(500);
                    }
                }
            }

        }
        private async Task HandleSetInfo()
        {
            string previousMessage = string.Empty;
            using (var mmf = MemoryMappedFile.CreateOrOpen("TestBuilderSet", 1000))
            {
                using (var accessor = mmf.CreateViewAccessor())
                {
                   // NotifyColleagues("ADDSetLog", "start");
                    //MessageBox.Show("TestBuilderSet Create");

                    while (true)
                    {
                        byte[] buffer = new byte[1000];
                        accessor.ReadArray<byte>(0, buffer, 0, buffer.Length);
                        string newMessage = Encoding.ASCII.GetString(buffer).Trim('\0');
                        //Console.WriteLine(newMessage);
                        if (newMessage != previousMessage&&newMessage!="")
                        {
                            previousMessage = newMessage;
                            NotifyColleagues("ADDSetLog", newMessage);
                            if (newMessage.Split("->")[0].Contains(","))
                            {
                                //NotifyColleagues("ADDSetLog", "Two CPM : "+ newMessage.Split("->")[0].Split(",")[0]+","+ newMessage.Split("->")[0].Split(",")[0]+" : "+newMessage.Split("->")[1]);
                                NotifyColleagues("SENDTO", newMessage.Split("->")[0].Split(",")[0] + "!@#$%" + newMessage.Split("->")[1]);
                                NotifyColleagues("SENDTO", newMessage.Split("->")[0].Split(",")[1] + "!@#$%" + newMessage.Split("->")[1]);
                            }
                            else {

                                NotifyColleagues("SENDTO", newMessage.Split("->")[0]+"!@#$%"+ newMessage.Split("->")[1]);

                            }
                        }
                        System.Threading.Thread.Sleep(500);
                    }
                }
            }

        }



    }
}
