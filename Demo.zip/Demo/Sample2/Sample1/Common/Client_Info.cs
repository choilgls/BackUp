﻿using Sample1.View;
using Sample1.ViewModel;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace Sample1.Common
{
    
    public class Client_Info
    {
        public TcpClient Client;
        public string Name;
        public string Message;
        public static readonly List<Client_Info> client_Infos = new List<Client_Info>();
        public Client_Info(TcpClient client)
        {
            Client = client;
            string ip = ((IPEndPoint)client.Client.RemoteEndPoint).Address.ToString();
            //MessageBox.Show(ip);
            //Name = client.Client.RemoteEndPoint.ToString().Split(':')[1];
            Name =ip;
            Message = "";
           
        }
    }
}
