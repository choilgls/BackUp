﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using static Sample1.Common.Mediator;

namespace Sample1.ViewModel
{

    public class OperateViewModel : ViewModelBase
    {
        public OperateViewModel()
        {
            Register("ADDSetLog", ADDSetLog);
        }


        private static ObservableCollection<string> _setLogList = new ObservableCollection<string>();
        public ObservableCollection<string> SetLogList
        {
            get
            {
                return _setLogList;
            }
            set
            {
                _setLogList = value;
                OnPropertyChanged("SetLogList");
            }
        }
        public void ADDSetLog(object obj)
        {
            string str = obj.ToString();
            DateTime time = DateTime.Now;
            long milliseconds = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
            DispatcherService.Invoke((System.Action)(() =>
            {
                SetLogList.Add(time.ToString("HH:mm:ss") + "\t" + str);
                //LogList.Add(str);
            }));

        }

    }
}
