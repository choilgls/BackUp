﻿using Sample1.Common;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Sample1.Common.Mediator;

namespace Sample1.Model
{

    public class LogVIewModel : ViewModelBase
    {
        public LogVIewModel()
        {
            Register("ADDLOG", AddLog);
        }

        public static event Action<string> LogListViewAction = null;

        private static ObservableCollection<string> _logList = new ObservableCollection<string>();
        public ObservableCollection<string> LogList
        {
            get
            {
                return _logList;
            }
            set
            {
                _logList = value;
                OnPropertyChanged("LogList");
            }
        }
        public void AddLog(object obj)
        {
            string str = obj.ToString();
            DateTime time = DateTime.Now;
            long milliseconds = DateTime.Now.Ticks / TimeSpan.TicksPerMillisecond;
            DispatcherService.Invoke((System.Action)(() =>
            {
                LogList.Add(time.ToString("HH:mm:ss.fffff") + "\t" + str );
                //LogList.Add(str);
            }));

        }
    }
}
